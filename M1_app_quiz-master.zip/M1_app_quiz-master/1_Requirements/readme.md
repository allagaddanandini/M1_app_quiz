# Identifying features 

# State of art/Research 

# 4W's 1-H 

# SWOT analysis

# High level requirements as per template 

# Low level requirements as per template

# Best Methods followed

