## a. Header files are written and they contain 

## b. Source code file 

## c. Makefile to compile the code

## d. Doxygen comments and relevant naming conventions 

## Best Methods followed 
